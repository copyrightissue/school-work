# 


#print("error, try again")
#print("Average: " + str(average))
