# Chris Rogers
num1 = int(input('Enter whole number:'))
count = 1
sums = 0
if num1 < 0:
    print ('0')
else:
    while count <= num1:
            sums += count
            count += 1

print ({sums})
