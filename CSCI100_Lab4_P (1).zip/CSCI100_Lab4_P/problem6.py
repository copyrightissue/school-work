# 
#import random


#secret = random.randint(1, numNumbers)



#print("Guess Lower")
#print("Guess Higher")
#print("Correct after " + str(guessCount) + " guesses")
