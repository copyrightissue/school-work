# Chris Rogers
import time
sums = 0
count = 10
while count > sums:
    time.sleep(1)
    print (count)
    count += -1
time.sleep(1)
print ('Blast Off!')
#print("Blast Off")
