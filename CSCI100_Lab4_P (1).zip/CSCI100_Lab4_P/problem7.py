# 





#print("Even Average: " + str(evenAverage))
#print("Odd Average: " + str(oddAverage))
