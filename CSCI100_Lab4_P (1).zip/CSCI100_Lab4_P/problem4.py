# name



#print("Average: " + str(average))
